# 04-fondazione-debole

φ=30° nel riempimento; φ=22° sotto il piano di posa.

Aprire modello.anthea, Terreno → Stabilità globale. I parametri, le combinazioni e il dominio di ricerca sono salvati nel file. Vista Verifiche → Stabilità globale.

## Confronto MAX 16

Questa cartella contiene il modello e i risultati ANTHEA. Lo stato del confronto indipendente MAX è documentato in stato-max.json e nel rapporto della raccolta.

Per confrontare: impostare Bishop, terreno, falda, carichi e fattori identici a risultati-anthea.json. Confrontare prima il medesimo cerchio (xc, yc, R), quindi la ricerca con il medesimo dominio; documentare conci, esclusioni, fattori e versione MAX. Non confrontare F caratteristico con F su parametri M2 ridotti.

- Globale A2–M2–R2 1: F=0,9516968108; η=1,155830289; Non soddisfatta; risolte 1000/2748.
- Globale A2–M2–R2 2: F=0,876703062; η=1,254700762; Non soddisfatta; risolte 1085/2839.